// FR — translation stub. The i18n loader falls back to English for any key
// not present here. To translate: copy keys from en.js, replace values.
// Status flips from "stub" to "full" when all keys are filled.
export const fr = {
  // intentionally empty — English fallback is used
};
