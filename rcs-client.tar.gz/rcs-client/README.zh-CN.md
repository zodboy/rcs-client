# RCS 客户端

为 rcsd 风控订阅平台构建的 Tauri 2 桌面客户端。是个"瘦遥控器"——重活(风控评估、AI 巡检、策略授权)都在 VPS 上的 rcsd 里跑,客户端只负责让用户登录、查看状态、把自己的 AI key 和交易所 key 加密上传到服务器。

支持 Windows / macOS / Linux,UI 内置中英文,西/日/法/德四种语言作为占位待翻译。

---

## 准备工作

在你打算开发或打包客户端的那台机器上需要:

- **Node.js 20+** 和 `npm`
- **Rust 1.77+**——从 https://rustup.rs 装
- 系统依赖:
  - **Windows:** WebView2 runtime(Win11 和现代 Win10 已自带);Visual Studio 2022 Build Tools 勾选"使用 C++ 的桌面开发"工作负载
  - **macOS:** Xcode Command Line Tools(`xcode-select --install`)
  - **Linux:** `libwebkit2gtk-4.1-dev libsoup-3.0-dev libgtk-3-dev libayatana-appindicator3-dev librsvg2-dev build-essential`

**对国内用户的重要提示:** Tauri 第一次构建会从 crates.io 拉 500+ 个 Rust 包,合计约 45 MB。直连国外速度慢。建议先配 cargo 镜像,在 `%USERPROFILE%\.cargo\config.toml`(Windows)或 `~/.cargo/config.toml`(Linux/Mac)写:

```toml
[source.crates-io]
replace-with = 'tuna'

[source.tuna]
registry = "sparse+https://mirrors.tuna.tsinghua.edu.cn/crates.io-index/"

[net]
git-fetch-with-cli = true
```

清华镜像不行就换中科大(`mirrors.ustc.edu.cn`)或字节(`mirrors.bfsu.edu.cn`)。

---

## 开发模式(改 UI、调试用)

```sh
cd rcs-client
npm install --ignore-scripts        # --ignore-scripts 阻断 npm 供应链攻击
npm run tauri dev
```

第一次 Rust 编译 10-30 分钟,之后改 JS/CSS 是热重载秒级响应。

dev 模式弹出的窗口里运行的 exe(`src-tauri\target\debug\rcs-client.exe`)**不能脱离 `npm run tauri dev` 单独跑**——它启动时要连本地 Vite 服务器(`http://127.0.0.1:5173`)拿前端代码,直接双击会报"127.0.0.1 拒绝连接"。dev 版本仅供开发调试。

---

## 构建给用户的安装包

```sh
npm run tauri build
```

第一次 release 编译 20-40 分钟(优化级别比 dev 高,还要打安装包)。产物在 `src-tauri\target\release\bundle\` 下:

- **Windows:** `nsis\RCS_0.1.0_x64-setup.exe`(NSIS 安装器)
- **macOS:** `dmg\RCS_0.1.0_aarch64.dmg`
- **Linux:** `deb\rcs-client_0.1.0_amd64.deb`、`appimage\rcs-client_0.1.0_amd64.AppImage`、`rpm\rcs-client-0.1.0-1.x86_64.rpm`

如果 MSI 打包失败而 NSIS 正常,在 `src-tauri\tauri.conf.json` 里把 `"targets"` 改成 `["nsis"]` 跳过 MSI。绝大多数 Windows 桌面应用都只发 NSIS,够用。

**Tauri 不能跨平台交叉编译:** Windows 上只能打 Windows 包,Mac 同理,Linux 同理。三平台都打要么三台机器各跑一次,要么用 GitHub Actions 的 `tauri-action` 自动化(README 末尾有链接)。

release 模式的 exe 不依赖任何外部服务——前端 HTML/CSS/JS 全部嵌入二进制,用户拿到安装包后双击装好,从开始菜单启动应用,**不需要也不会**连本地任何端口。

---

## 上线必改的几个地方

打包给用户之前必须改这几处:

### 1. 注册网址(`src/js/views/auth.js` 顶部)

```js
const REG_URL = "https://your-registration-site.example.com/signup";
```

改成你的注册网站真实地址。这是登录界面"还没有订阅?前往注册"按钮跳转的目标。

### 2. 应用元数据(`src-tauri/tauri.conf.json`)

```json
{
  "productName": "RCS",                  // 显示名
  "version": "0.1.0",                    // 你的版本号
  "identifier": "com.rcs.client",        // 反向域名,要改成你的域
  ...
}
```

`identifier` 必须改——Tauri 用它作为安装路径、注册表项、macOS bundle id 的唯一标识,默认值留着发布会和别的 RCS 项目冲突。

### 3. 应用图标

我放了占位渐变图标在 `src-tauri/icons/`。要换自己的:

```sh
# 准备一张 1024x1024 的 PNG 放到 icon.png,然后:
npx @tauri-apps/cli icon src-tauri/icons/icon.png
```

会自动生成所有平台需要的尺寸和格式(`.ico`/`.icns`/PNG 系列)。

### 4. 策略目录(`src/js/views/strategies.js`)

```js
const STRATEGY_LABELS = {
  "sports_dc":   { name: "Sports — Dixon-Coles",         tag: "Poisson model + Kelly"  },
  "okx_daemon":  { name: "OKX live daemon",              tag: "spot + perp"            },
  ...
};
```

这是你 VPS 上提供的策略目录的展示名映射。客户端不知道服务器上有什么策略,这张表告诉它"`sports_dc` 这个 id 对应的中文/英文名叫什么、副标题是什么"。**每加一个新策略,就在这里补一条。** 不在这里的策略 id 客户端会显示为原始 id 字符串,功能上不影响,只是不好看。

将来如果策略种类太多,可以改成从 rcsd 拉一个目录接口,这里暂时硬编码。

### 5. 给所有用户面对的字符串做最终校对

`src/i18n/en.js` 和 `src/i18n/zh.js` 是面向用户的所有文本。打包前过一遍,把里面的"占位"内容(比如说服务器地址提示文案的示例 URL)替换成你的实际值。

---

## 用户怎么拿到 API 密钥(关键流程)

这是你最关心的问题——用户在你的网站买了订阅之后,怎么自动拿到客户端能用的密钥。

**完整数据流:**

```
用户 ──注册付款──> 你的注册网站 ──HTTP+HMAC──> rcsd /api/keys ──返回密钥──> 网站存库+展示给用户
                                                                                    │
                                                                                    └─ 用户复制 key_id 和 secret 填到客户端登录界面
```

**注册网站需要做的事**(这是另一个项目,见 `INTEGRATION.md`):

1. 用户登录注册,选档位,完成支付(走 Stripe / 微信支付 / 支付宝 / 任何你选的网关)
2. 支付成功的回调里,**网站后端**用你保管的 rcsd 主密钥调一次 `POST /api/keys`,带上档位和该用户的策略权限
3. rcsd 返回新铸造的 `key_id` 和 `secret`(secret 只返回这一次)
4. 网站把 `key_id` 存进自己的用户表(关联用户账号),`secret` 一次性展示给用户让他复制(或者发邮件)
5. 用户在客户端的登录界面填:服务器地址 + key_id + secret 即可

`secret` **绝对不要存进你的注册网站数据库**——rcsd 那边已经有它了,网站只需要保留 key_id 用来后续做"暂停/续期/注销"操作。

具体的 API 契约、签名算法、参考代码全部在 `INTEGRATION.md` 里,**写注册网站的人/AI 直接照着那个文档做就行。**

我同时在 `tools/issue_key.py` 放了一个可以直接跑的密钥签发参考脚本——你自己在终端就能跑一遍验证流程,产出真实的 key_id+secret,然后填到客户端登录测试。

---

## 多语言

语言切换按钮在右上角的地球图标。当前支持:

| 代码 | 名字 | 状态 |
|---|---|---|
| en | English | 完整 |
| zh | 中文 | 完整 |
| es | Español | 占位(回退到英文) |
| ja | 日本語 | 占位 |
| fr | Français | 占位 |
| de | Deutsch | 占位 |

占位文件在 `src/i18n/{es,ja,fr,de}.js`,目前是空对象——这意味着选这些语言时 UI 整体显示英文(系统按键 fallback)。要翻译某种语言:

1. 打开比如 `src/i18n/es.js`
2. 复制 `en.js` 里的所有 key
3. 替换 value 为西班牙语
4. 重新构建客户端,语言菜单里那条会自动从"部分"变成"完整"

不动结构,只填值。

---

## 项目结构

```
rcs-client/
├── index.html                  Vite 入口,挂载 App
├── package.json                npm 依赖
├── vite.config.js              Vite 配置
├── src/
│   ├── main.js                 启动、app shell、tab 路由、登录闸门
│   ├── css/app.css             整套设计系统(浅色 + 渐变点缀)
│   ├── i18n/
│   │   ├── en.js / zh.js       两个完整翻译
│   │   └── es/ja/fr/de.js      占位待翻译
│   └── js/
│       ├── i18n.js             多语言核心
│       ├── api.js              rcsd HTTP 客户端(HMAC 签名)
│       ├── session.js          密钥本地加密存储
│       ├── util.js             小工具(toast、escape、hex...)
│       ├── icons.js            内联 SVG 图标
│       └── views/
│           ├── auth.js         登录页
│           ├── home.js         首页(订阅概览)
│           ├── strategies.js   策略列表
│           ├── risk.js         风控规则查看 + 测试评估
│           ├── ai.js           AI key + 交易所 key + 巡检设置
│           └── me.js           个人页 + 退出登录
├── tools/
│   └── issue_key.py            密钥签发参考脚本(注册网站照着写)
├── INTEGRATION.md              注册网站接入文档(API 契约)
├── README.zh-CN.md             本文件
└── src-tauri/                  Tauri 原生壳子(Rust)
    ├── Cargo.toml              Rust 依赖
    ├── tauri.conf.json         应用配置(改这里换图标、名字)
    ├── capabilities/           插件权限
    ├── icons/                  应用图标
    └── src/
        ├── main.rs             桌面入口
        └── lib.rs              注册 HTTP / Store / Opener 插件
```

---

## 常见故障

**双击 dev 版本 exe 报"127.0.0.1 拒绝连接"**
你打开的是 `src-tauri\target\debug\rcs-client.exe`,这是开发版,要 Vite 服务器在跑才能用。release 版本在 `target\release\rcs-client.exe` 或安装包里,那个是独立的。

**MSI 打包失败,light.exe 报错**
基本上是路径问题。WiX 工具链不喜欢路径里有空格、点开头、中文、太长。两个办法:把项目搬到 `C:\rcs-client\` 这种简单路径;或者在 `tauri.conf.json` 里把 `"targets"` 改成 `["nsis"]` 跳过 MSI,只打 NSIS 安装器(单一 setup.exe,够用)。

**Rust 编译卡在某个 crate 几十分钟**
是 crates.io 下载慢。配镜像(见上面准备工作)。如果配了镜像还慢,可能镜像 502 了,换一个。

**`cargo metadata` 报 program not found**
没装 Rust。去 https://rustup.rs 装。

**找不到 link.exe**
没装 VS C++ 工作负载,或者装了但没装"使用 C++ 的桌面开发"。在 Visual Studio Installer 里点对应版本的"修改",勾上这个工作负载补装。

**第一次 `tauri dev` 不弹窗,卡在 "Compiling ..."**
没卡,在编译。Tauri 第一次要编 500+ 个 Rust crate,15-30 分钟正常。等。

**npm audit 报漏洞**
moderate 级别一般是 vite 或它的传递依赖里的常规 CVE,跟 npm 供应链蠕虫(Shai-Hulud)不是一回事。不要跑 `npm audit fix --force`,会把版本搞乱。直接忽略,等 Tauri 升级。**真要验证有没有中蠕虫,跑 `npm audit signatures` 而不是 `npm audit`。**

**国内访问 GitHub / crates.io 慢**
正常,中国大陆网络情况。配 cargo 镜像;另外构建时如果挂了梯子会更稳。

---

## 关于"应该另开一个对话做注册网站"

是的。注册网站是另一个独立项目:

- 不同的技术栈(用户系统 + 支付集成 + 数据库,通常 Python/Node/Go + 前端框架)
- 不同的部署(也是 VPS 上,但跟 rcsd 进程独立)
- 不同的关注点(用户认证、支付安全、订阅生命周期、退款处理)

但**注册网站只需要做一件事跟 rcsd 打交道**:支付成功后调 `POST /api/keys` 铸密钥。这一件事的完整契约 + 参考代码全部在 `INTEGRATION.md` 和 `tools/issue_key.py` 里。把这两份文件给写注册网站的人/AI,他能直接照做。

剩下的注册逻辑(用户表、登录、支付网关、退款、订阅续期)跟 rcsd 没关系,是注册网站自己的事。

---

## 还没做的两件事

1. **VPS 上的 Python 巡检守护进程(agent)**——客户端的"AI"标签页里所有上传操作都对接它的 `/api/agent/*` 端点。这个端点现在不存在,客户端会优雅地显示"等待 VPS agent 模块"。下一轮的工作。

2. **注册网站本身**——你下次另开对话做。

按你的节奏选下一步:
- "我先做巡检 agent" → 下次对话告诉我,Python+APScheduler,把 AI 巡检的活做掉
- "我先做注册网站" → 下次对话告诉我目标技术栈和支付网关,把网站做掉
- "都不急,我先把客户端发给几个早鸟用户试试" → 用 `tools/issue_key.py` 手动签发几把密钥分发即可
