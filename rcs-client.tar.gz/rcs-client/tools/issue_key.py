#!/usr/bin/env python3
"""
issue_key.py — 调用 rcsd 主密钥端点签发订阅密钥的命令行工具。

用途:
  1. 你自己手动给早鸟用户发密钥(在 VPS 上跑 / 本地跑都行)。
  2. 你的注册网站后端的参考实现——付款成功后调一次本脚本里的
     issue_key() 函数即可,逻辑见 INTEGRATION.md。

依赖:
  pip install requests        # 没 pip 就 pip3,Windows 上系统 Python 自带 venv 也行

用法示例:
  # 列出所有档位(确认 rcsd 在线、主密钥对)
  python issue_key.py tiers \\
      --endpoint https://your-vps.example.com:8090 \\
      --master-key 0011223344556677889900aabbccddeeff00112233445566778899aabbccddee

  # 签发一把启航版密钥,4 套策略,30 天有效
  python issue_key.py issue \\
      --endpoint https://your-vps.example.com:8090 \\
      --master-key $RCS_MASTER_KEY \\
      --label "alice@example.com" \\
      --tier launch \\
      --strategies sports_dc,okx_daemon,grid_v2,arb_x \\
      --expires +30d

  # 查询一把已存在的密钥
  python issue_key.py get \\
      --endpoint https://your-vps.example.com:8090 \\
      --master-key $RCS_MASTER_KEY \\
      --key-id rck_8fd85c01eb383bf5

  # 暂停一把密钥(用户欠费 / 退款后)
  python issue_key.py suspend ... --key-id rck_...

  # 恢复
  python issue_key.py activate ... --key-id rck_...

  # 轮换 secret(用户密钥泄漏后)
  python issue_key.py rotate ... --key-id rck_...

  # 删除
  python issue_key.py delete ... --key-id rck_...

提示:
  环境变量可以替代命令行参数,避免主密钥出现在 shell 历史里:
    export RCS_ENDPOINT=https://your-vps.example.com:8090
    export RCS_MASTER_KEY=00112233...
  然后命令行不用再写 --endpoint 和 --master-key。
"""

import argparse
import hashlib
import hmac
import json
import os
import re
import sys
import time

try:
    import requests
except ImportError:
    print("缺少 requests 库,执行 'pip install requests' 后重试。", file=sys.stderr)
    sys.exit(2)


# ---------- 核心:HMAC 签名 + HTTP 调用 ----------

def call_rcsd(endpoint: str, master_key_hex: str, method: str,
              path: str, body: dict | None = None) -> tuple[int, dict | str]:
    """对 rcsd 发一次主密钥签名的请求。返回 (status_code, parsed_json_or_text)."""
    master_key = bytes.fromhex(master_key_hex)
    body_str = json.dumps(body, separators=(",", ":")) if body is not None else ""
    ts = str(int(time.time()))
    canon = f"{method}\n{path}\n{ts}\n{body_str}".encode("utf-8")
    sig = hmac.new(master_key, canon, hashlib.sha256).hexdigest()

    headers = {"X-RCS-Ts": ts, "X-RCS-Auth": sig}
    if body_str:
        headers["Content-Type"] = "application/json"

    url = endpoint.rstrip("/") + path
    resp = requests.request(method, url, data=body_str or None,
                            headers=headers, timeout=15)
    try:
        parsed = resp.json()
    except ValueError:
        parsed = resp.text
    return resp.status_code, parsed


# ---------- 给注册网站后端用的高层函数 ----------

def issue_subscription_key(endpoint: str, master_key_hex: str, *,
                           label: str, tier: str, strategies: str,
                           expires: int = 0, rate_per_min: int = 0) -> dict:
    """
    签发一把订阅密钥。返回的 dict 含 key_id 和 secret(secret 只在这次响应里)。
    把它当作注册网站后端的"付款成功回调"里要调的函数原型。

    raises requests.HTTPError 在失败时;调用方应该 catch 这个并合适地告诉用户
    "签发失败,请联系客服" 而不是抛 500。
    """
    body = {"label": label, "tier": tier, "strategies": strategies}
    if expires:      body["expires"] = expires
    if rate_per_min: body["rate_per_min"] = rate_per_min

    code, data = call_rcsd(endpoint, master_key_hex, "POST", "/api/keys", body)
    if code != 201:
        raise RuntimeError(f"签发失败 (HTTP {code}): {data}")
    return data


# ---------- 命令行入口 ----------

def parse_expires(s: str) -> int:
    """支持 '+30d' '+90d' '+1y' '0' '永不' 或原始 unix 秒。返回 unix 秒。"""
    if not s or s in ("0", "永不", "never"):
        return 0
    m = re.match(r"^\+(\d+)([dhwy])$", s)
    if m:
        n = int(m.group(1))
        mult = {"h": 3600, "d": 86400, "w": 86400 * 7, "y": 86400 * 365}[m.group(2)]
        return int(time.time()) + n * mult
    try:
        return int(s)
    except ValueError:
        raise SystemExit(f"无法解析 expires 值: {s}(支持 +30d, +1y, unix秒, 或 0)")


def pretty(data, indent=2):
    if isinstance(data, dict):
        print(json.dumps(data, indent=indent, ensure_ascii=False))
    else:
        print(data)


def main():
    p = argparse.ArgumentParser(description="rcsd 订阅密钥签发工具")
    p.add_argument("action",
                   choices=["tiers", "issue", "get", "list", "update", "suspend",
                            "activate", "rotate", "delete"],
                   help="操作类型")
    p.add_argument("--endpoint", default=os.environ.get("RCS_ENDPOINT"),
                   help="rcsd 地址,如 https://your-vps:8090(或 RCS_ENDPOINT 环境变量)")
    p.add_argument("--master-key", default=os.environ.get("RCS_MASTER_KEY"),
                   help="主密钥 64 位十六进制(或 RCS_MASTER_KEY 环境变量)")
    p.add_argument("--key-id")
    p.add_argument("--label")
    p.add_argument("--tier")
    p.add_argument("--strategies", help="逗号分隔 / * 通配")
    p.add_argument("--expires", default="0", help="到期时间,如 +30d / +1y / unix秒 / 0(永不)")
    p.add_argument("--rate-per-min", type=int, default=0)

    args = p.parse_args()
    if not args.endpoint or not args.master_key:
        print("错误:必须提供 --endpoint 和 --master-key(或设置同名环境变量)",
              file=sys.stderr)
        sys.exit(1)

    A = args.action

    if A == "tiers":
        code, data = call_rcsd(args.endpoint, args.master_key, "GET", "/api/tiers")
        print(f"HTTP {code}")
        pretty(data)
        return

    if A == "list":
        code, data = call_rcsd(args.endpoint, args.master_key, "GET", "/api/keys")
        print(f"HTTP {code}")
        pretty(data)
        return

    if A == "issue":
        for need in ("label", "tier", "strategies"):
            if not getattr(args, need):
                print(f"错误:issue 需要 --{need}", file=sys.stderr); sys.exit(1)
        result = issue_subscription_key(
            args.endpoint, args.master_key,
            label=args.label, tier=args.tier, strategies=args.strategies,
            expires=parse_expires(args.expires),
            rate_per_min=args.rate_per_min,
        )
        print("=" * 60)
        print("✓ 密钥签发成功")
        print("=" * 60)
        print(f"key_id:       {result['key_id']}")
        print(f"secret:       {result['secret']}")
        print(f"tier:         {result.get('tier_label', result['tier'])}")
        print(f"strategies:   {result['strategies']}")
        if result.get("expires"):
            from datetime import datetime
            print(f"expires:      {datetime.fromtimestamp(result['expires'])}")
        print("=" * 60)
        print("把 key_id 和 secret 一起给用户。secret 不会再出现一次。")
        print("用户在客户端登录界面填:")
        print(f"  服务器:  {args.endpoint}")
        print(f"  Key ID:  {result['key_id']}")
        print(f"  Secret:  {result['secret']}")
        return

    if A in ("get", "delete"):
        if not args.key_id:
            print(f"错误:{A} 需要 --key-id", file=sys.stderr); sys.exit(1)
        method = "DELETE" if A == "delete" else "GET"
        code, data = call_rcsd(args.endpoint, args.master_key, method,
                               f"/api/keys/{args.key_id}")
        print(f"HTTP {code}")
        pretty(data)
        return

    if A == "rotate":
        if not args.key_id:
            print("错误:rotate 需要 --key-id", file=sys.stderr); sys.exit(1)
        code, data = call_rcsd(args.endpoint, args.master_key, "POST",
                               f"/api/keys/{args.key_id}/rotate")
        print(f"HTTP {code}")
        if code == 200:
            print("✓ secret 已轮换。新 secret(只出现一次):")
            print(f"  {data['secret']}")
            print("旧 secret 立即失效。")
        else:
            pretty(data)
        return

    if A in ("suspend", "activate", "update"):
        if not args.key_id:
            print(f"错误:{A} 需要 --key-id", file=sys.stderr); sys.exit(1)
        # PUT 是全量替换,先 GET 再改
        code, current = call_rcsd(args.endpoint, args.master_key, "GET",
                                  f"/api/keys/{args.key_id}")
        if code != 200:
            print(f"获取当前密钥失败 (HTTP {code}): {current}"); sys.exit(2)

        if A == "suspend":  current["status"] = "suspended"
        if A == "activate": current["status"] = "active"
        if A == "update":
            if args.label is not None:        current["label"] = args.label
            if args.tier:                     current["tier"] = args.tier
            if args.strategies is not None:   current["strategies"] = args.strategies
            if args.expires != "0":           current["expires"] = parse_expires(args.expires)
            if args.rate_per_min:             current["rate_per_min"] = args.rate_per_min

        # rcsd 的 PUT 不需要 secret 字段(也没法提供,GET 不返回 secret),把它清掉
        current.pop("secret", None)
        current.pop("tier_label", None)
        code, data = call_rcsd(args.endpoint, args.master_key, "PUT",
                               f"/api/keys/{args.key_id}", current)
        print(f"HTTP {code}")
        pretty(data)
        return


if __name__ == "__main__":
    main()
