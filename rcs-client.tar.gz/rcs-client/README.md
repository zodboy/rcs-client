# RCS Client

Tauri 2 desktop client for the rcsd risk-control platform. A thin, polished remote — all heavy lifting (risk evaluation, AI patrol, strategy entitlements) lives on your VPS in rcsd. The client just authenticates with the user's subscription key and shows status / lets them push their AI + exchange credentials up to the patrol agent.

## What's here

```
rcs-client/
├── index.html                  Vite entry; mounts the app shell
├── package.json                npm deps + scripts
├── vite.config.js              Vite dev server (:5173, no auto-open)
├── src/
│   ├── main.js                 boot, shell, routing, auth gate, language menu
│   ├── css/app.css             full design system — light, gradient accents
│   ├── i18n/
│   │   ├── en.js  (full)       canonical key reference
│   │   ├── zh.js  (full)       中文
│   │   ├── es.js  (stub)       Español — falls back to EN per-key
│   │   ├── ja.js  (stub)       日本語
│   │   ├── fr.js  (stub)       Français
│   │   └── de.js  (stub)       Deutsch
│   └── js/
│       ├── i18n.js             language registry, t(), formatters
│       ├── api.js              rcsd API client (HMAC signing, Tauri-HTTP)
│       ├── session.js          encrypted session store
│       ├── util.js             small helpers: hex, esc, toast, fmtError
│       ├── icons.js            inline SVG icons + tab-bar gradient defs
│       └── views/
│           ├── auth.js         sign-in screen
│           ├── home.js         hero card + server health
│           ├── strategies.js   strategy catalog with allowed/denied state
│           ├── risk.js         active rules + evaluation tester
│           ├── ai.js           AI key upload + patrol config (agent stubs)
│           └── me.js           profile + sign-out
└── src-tauri/                  Tauri 2 native shell
    ├── Cargo.toml              Rust deps; release profile = LTO + strip
    ├── build.rs                tauri-build glue
    ├── tauri.conf.json         app metadata, window, bundle, CSP
    ├── capabilities/default.json   plugin permissions
    ├── icons/                  rendered PNGs (regenerate via `tauri icon`)
    └── src/
        ├── main.rs             desktop entry point
        └── lib.rs              registers http/store/opener plugins
```

## Prerequisites

- **Node.js 20+** and a package manager (`npm`, `pnpm`, or `yarn`)
- **Rust 1.77+** — install via `rustup` (https://rustup.rs)
- Platform deps:
  - **Linux:** `libwebkit2gtk-4.1-dev`, `libsoup-3.0-dev`, `libgtk-3-dev`, `libayatana-appindicator3-dev`, `librsvg2-dev`, `build-essential`
  - **macOS:** Xcode Command Line Tools (`xcode-select --install`)
  - **Windows:** WebView2 runtime (preinstalled on Windows 11 / modern Win10), Visual Studio 2022 Build Tools with the "Desktop development with C++" workload

## Install + run

```sh
cd rcs-client
npm install
npm run tauri dev
```

A native window opens. The first build of the Rust side takes a few minutes; subsequent rebuilds are seconds.

To run against a real rcsd, you need:

1. rcsd deployed at some URL (e.g. `https://your-vps.example.com:8090`)
2. A subscription key issued via `POST /api/keys` from rcsd's admin console
   (the master key path). You get back `key_id` (`rck_…`) and `secret` (64-hex), shown once.
3. Type the endpoint, key id, and secret into the client's sign-in screen.

## Build production binaries

```sh
npm run tauri build
```

Output lives in `src-tauri/target/release/bundle/`:

- **Linux:** `.deb`, `.rpm`, `.AppImage`
- **macOS:** `.app`, `.dmg`
- **Windows:** `.msi`, `.exe` (NSIS installer)

Cross-compilation is awkward in Tauri — build on each target platform, or use a CI matrix. GitHub Actions has well-known `tauri-action` workflows for this.

## Icons

The starter icons are rendered programmatically (a gradient rounded square with the brand check mark). To replace with your real artwork:

```sh
# Put a 1024x1024 PNG at src-tauri/icons/icon.png, then:
npx @tauri-apps/cli icon src-tauri/icons/icon.png
```

This regenerates every platform format (`.icns` for macOS, `.ico` for Windows, the PNG ladder, etc.).

## Languages

The language switcher (top-right globe button) is always available. The launch list:

| code | label    | status   |
|------|----------|----------|
| en   | English  | full     |
| zh   | 中文     | full     |
| es   | Español  | stub     |
| ja   | 日本語   | stub     |
| fr   | Français | stub     |
| de   | Deutsch  | stub     |

**Stub** files (`src/i18n/{es,ja,fr,de}.js`) are real source files with an empty object — the `t()` lookup falls back to English key-by-key. To translate a language: open the stub file, paste keys from `en.js`, replace values. The "partial" badge in the language menu flips to "complete" automatically when the file is full.

The canonical key list is in `src/i18n/en.js`. Don't invent new keys outside that file — add them there first, then mirror as needed.

## How the auth works

The client uses the same HMAC-SHA256 scheme rcsd's admin console does:

- canonical string: `METHOD\nPATH\nTS\n` + body
- `X-RCS-Ts`: unix seconds, ±30s window
- `X-RCS-Auth`: lowercase hex HMAC-SHA256
- `X-RCS-Key-Id`: required (this client always uses subscriber keys)

The secret is computed via `crypto.subtle.sign('HMAC')` in the WebView, then sent. The secret never leaves local storage in plaintext on the wire — only the per-request signature does.

Network calls go through Tauri's `@tauri-apps/plugin-http`, which bypasses the WebView's same-origin sandbox. In `vite dev` (browser-only fallback) it uses `fetch`, which works for any rcsd that allows CORS from `http://127.0.0.1:5173` — otherwise dev with the full Tauri shell (`npm run tauri dev`).

## Pending integration points (agent module on the VPS)

The "AI" tab is fully built but its endpoints (`/api/agent/config`, `/api/agent/creds/<provider>`, `/api/agent/reports`) don't exist in rcsd yet. The client gracefully shows a "awaiting VPS agent module" banner and surfaces 404s as a friendly toast. When you ship the Python patrol daemon (next iteration), implement these routes — the client will start working immediately, no code change needed.

Endpoint contract the client expects:

```
GET  /api/agent/config              -> { enabled, period_min, conditions, task }
PUT  /api/agent/config              <-  same shape
GET  /api/agent/creds/<provider>    -> { provider, model?, has_key: bool }   (NEVER the actual secret)
PUT  /api/agent/creds/<provider>    <-  { provider, api_key, model? } or { exchange, api_key, api_secret, passphrase? }
GET  /api/agent/reports/<limit>     -> { reports: [{ ts, summary, action, ... }, ...] }
```

Auth: subscriber HMAC (same as every other endpoint, with `X-RCS-Key-Id`). Storage on the VPS: credentials must be encrypted at rest with a key derived from something the rcsd master operator controls — don't store them plaintext like the subscriber-key secrets currently are.

## Design system reference

The visual style is "Instagram-adjacent" — light theme, generous whitespace, rounded cards, soft shadows, the brand gradient (`#515bd4 → #dd2a7b → #f58529`) used sparingly on:

- the app logo + hero card background
- primary action button (`.btn-grad`)
- active-tab indicator at the top of `.tabbar` buttons
- soft accent backgrounds (`.list-row .lr-ico`, `.grad-soft`)
- text accents via `.grad-text` (uses `background-clip: text`)

CSS variables in `:root` control everything. To darken to a dark theme later, override the `--bg / --surface / --text*` group; nothing else needs to change.

## Known limits

- **No remember-me on the auth screen.** The session store persists silently after a successful sign-in; if the user wants to drop it, the sign-out button on the Profile tab clears it. There's no "stay signed in" checkbox because there's no other mode.
- **The strategy catalog is a hard-coded label table** (`STRATEGY_LABELS` in `src/js/views/strategies.js`). When you add a new strategy id on the server side, add a matching display label here. A future iteration could fetch the catalog from rcsd.
- **Risk tab `/api/rules` requires master access.** Subscribers get 403; the view detects this and falls back to a generic note. If you want subscribers to see the rules, add a read-only `/api/rules/public` endpoint in rcsd that strips internal fields.
- **The evaluation tester sends a fixed `symbol: "BTC-USDT"`** to keep the form short. Edit `src/js/views/risk.js` if you need it parameterised.
- **Browser fetch in `vite dev` will be blocked by CORS** unless rcsd allows your dev origin. Develop with `npm run tauri dev` for the realistic auth/HTTP path.
