# 注册网站 → rcsd 接入契约

本文档写给**做注册网站**的人(或 AI)。RCS 客户端本身不读这个文件,它只是放在 rcs-client 仓库里方便集中管理。

注册网站的核心职责:用户付款成功后,**调一次 rcsd 的 `/api/keys` 接口**,把订阅密钥铸出来,展示给用户(或邮件发给用户)。仅此而已——剩下的用户表、支付、邮件、续期 UI 都是网站自己的事,跟 rcsd 没关系。

---

## 一、你需要的东西

1. **rcsd 的对外地址**——比如 `https://your-vps.example.com:8090`(强烈建议套 HTTPS 反代,见下文安全章节)
2. **rcsd 的主密钥**(`RCS_AUTH_KEY_HEX` 环境变量的值)——64 位十六进制字符串,32 字节。这把密钥**只放在你网站后端的服务器上**,绝对不能进前端、不能进 git、不能发邮件。它能签发任何档位的任何密钥,泄漏等于丢失整个用户系统的控制权。
3. **档位 → 策略列表的映射表**——你网站决定每个档位包含哪些策略。比如:
   ```
   free      → "sports_dc"
   launch    → "sports_dc,okx_daemon,grid_v2,arb_x"
   pro       → "sports_dc,okx_daemon,grid_v2,arb_x,trend_btc,vol_target,mean_rev,options_iv"
   flagship  → "*"   (通配,所有策略)
   ```

---

## 二、签发密钥的接口

### HTTP 请求

```
POST /api/keys
Host: your-vps.example.com:8090
Content-Type: application/json
X-RCS-Ts: <unix秒时间戳>
X-RCS-Auth: <HMAC-SHA256 签名,小写十六进制>

{"label":"alice@example.com","tier":"launch","strategies":"sports_dc,okx_daemon,grid_v2,arb_x","expires":1747353600,"rate_per_min":240}
```

字段说明:
- `label`(string,可选):你内部用的标识。建议放用户邮箱或用户 id,方便日后核对。
- `tier`(string,必填):`free` / `launch` / `pro` / `flagship` 中之一。必须和 rcsd 那边 `/api/tiers` 里定义的一致。
- `strategies`(string,可选):逗号分隔的策略 id 列表,或者 `*` 通配。**会按 tier 的 `max_strategies` 限制检查**——比如 free 档最多 1 个策略,传 2 个会被 422 拒绝。
- `expires`(int,可选):Unix 秒,密钥到期时间。`0` 或不传 = 永不过期。
- `rate_per_min`(int,可选):该密钥每分钟最大请求数。不传则用 tier 的默认速率。

### HMAC 签名怎么算

规范字符串:`METHOD\nPATH\nTS\n` + 请求体原文。`PATH` 是不含 query string 的纯路径,`\n` 是真实换行符。

伪代码:
```
canonical = "POST" + "\n" + "/api/keys" + "\n" + str(ts) + "\n" + body_json
signature = hex(hmac_sha256(master_key_bytes, canonical_bytes))
```

`master_key_bytes` 是把 `RCS_AUTH_KEY_HEX` 这 64 字符十六进制 decode 成 32 字节 bytes,**不是直接用字符串**。

### 成功响应(`201 Created`)

```json
{
  "key_id":       "rck_8fd85c01eb383bf5",
  "secret":       "5bcae9d4f0...一长串64位十六进制...",
  "label":        "alice@example.com",
  "tier":         "launch",
  "tier_label":   "启航版",
  "strategies":   "sports_dc,okx_daemon,grid_v2,arb_x",
  "status":       "active",
  "rate_per_min": 240,
  "created":      1715920000,
  "expires":      1747353600
}
```

**关键点:`secret` 字段只在这次响应里出现,以后再也不返回。** 任何后续接口(列表、单个查询、轮换)都不返回 secret。你的网站后端拿到这个响应后:

1. **立即把 `key_id` 存进网站自己的用户表**,关联到该用户的订阅订单
2. **`secret` 一次性展示给用户**——展示页可以用大字体、可复制按钮、再加个"邮件发送"的按钮做兜底
3. **绝对不要把 `secret` 存进你的网站数据库**——rcsd 那边已经有它了,你网站不需要保留(也不应该保留——多一处存储就多一处泄漏面)

### 错误响应

- `401 unauthorized`:HMAC 签名错了或者时间戳偏差 > 30 秒。检查时钟同步、签名实现、master key 是不是对的。
- `403 forbidden`:你用了订阅密钥而不是主密钥——`/api/keys` 只接受主密钥。检查请求里**不要**带 `X-RCS-Key-Id` 头。
- `422 create_failed`:档位限制冲突,detail 字段说原因。最常见的是策略数超过 tier 上限。
- `429 rate_limited`:网站后端在每分钟内调了太多次。极少出现,如果出现说明你网站有 bug 在死循环签发。

---

## 三、生命周期里的其他操作

### 查询某把密钥

```
GET /api/keys/rck_8fd85c01eb383bf5
```

返回不含 secret 的所有字段。网站可以用这个核对密钥还在不在、状态怎样。

### 暂停密钥(用户欠费、退款后)

```
PUT /api/keys/rck_8fd85c01eb383bf5
Content-Type: application/json

{"label":"...","tier":"launch","strategies":"...","status":"suspended"}
```

注意 PUT 是**全量替换**,你要先 GET 一次拿到当前所有字段,改 `status` 字段后再 PUT 回去。被 suspended 的密钥下次请求 rcsd 会直接 403。

恢复就是改 `status` 为 `active` 再 PUT。

### 续期(改到期时间)

同上 PUT,改 `expires` 字段(Unix 秒)。

### 升级 / 降级档位

同上 PUT,改 `tier` 和 `strategies` 字段。**注意:tier 改了之后 strategies 必须满足新 tier 的 `max_strategies` 上限**,否则 422。降级到 free 时记得把 strategies 缩到 1 个。

### 用户密钥泄漏了要轮换

```
POST /api/keys/rck_8fd85c01eb383bf5/rotate
```

返回新 secret(也是只出现这一次)。旧 secret **立即失效**。展示给用户让他重新填到客户端。

### 用户注销账号

```
DELETE /api/keys/rck_8fd85c01eb383bf5
```

不可逆。彻底删除。

---

## 四、Python 参考实现

```python
import hashlib, hmac, json, time, requests

RCSD_URL    = "https://your-vps.example.com:8090"
MASTER_KEY  = bytes.fromhex("把你的 RCS_AUTH_KEY_HEX 填这里")

def call_rcsd(method: str, path: str, body: dict | None = None) -> dict:
    body_str = json.dumps(body, separators=(",", ":")) if body else ""
    ts       = str(int(time.time()))
    canon    = f"{method}\n{path}\n{ts}\n{body_str}".encode("utf-8")
    sig      = hmac.new(MASTER_KEY, canon, hashlib.sha256).hexdigest()

    headers = {"X-RCS-Ts": ts, "X-RCS-Auth": sig}
    if body_str:
        headers["Content-Type"] = "application/json"

    r = requests.request(method, RCSD_URL + path, data=body_str or None, headers=headers, timeout=10)
    r.raise_for_status()
    return r.json()

# 用户付款成功后调:
def issue_subscription_key(user_email: str, tier: str, expires_at: int) -> dict:
    """
    付款成功的回调里调一次。返回的 dict 含 key_id 和 secret(secret 只出现这一次)。
    """
    TIER_STRATEGIES = {
        "free":     "sports_dc",
        "launch":   "sports_dc,okx_daemon,grid_v2,arb_x",
        "pro":      "sports_dc,okx_daemon,grid_v2,arb_x,trend_btc,vol_target,mean_rev,options_iv",
        "flagship": "*",
    }
    return call_rcsd("POST", "/api/keys", {
        "label":      user_email,
        "tier":       tier,
        "strategies": TIER_STRATEGIES[tier],
        "expires":    expires_at,
    })

# 用户退款后调:
def suspend_key(key_id: str):
    current = call_rcsd("GET", f"/api/keys/{key_id}")
    current["status"] = "suspended"
    call_rcsd("PUT", f"/api/keys/{key_id}", current)
```

完整的、可在命令行直接跑的版本见 `tools/issue_key.py`——拿你自己的 rcsd 地址和主密钥跑一遍,验证整个流程,然后把生成的 key_id+secret 填到客户端登录测试。

---

## 五、其他后端语言的实现要点

签名算法不依赖任何特殊库,任何语言都能做。核心三步:

1. 把 master key 的 64 字符 hex string decode 成 32 字节
2. 拼规范字符串 `METHOD\nPATH\nTS\nBODY`(`\n` 是真实换行,不是字面 `\n` 字符)
3. HMAC-SHA256,结果转**小写**十六进制

### Node.js

```js
const crypto = require('crypto');
const key = Buffer.from(MASTER_KEY_HEX, 'hex');
const ts = Math.floor(Date.now() / 1000).toString();
const canon = `${method}\n${path}\n${ts}\n${body || ''}`;
const sig = crypto.createHmac('sha256', key).update(canon).digest('hex');
```

### PHP

```php
$key = hex2bin($masterKeyHex);
$ts = (string) time();
$canon = "$method\n$path\n$ts\n$body";
$sig = hash_hmac('sha256', $canon, $key);
```

### Go

```go
key, _ := hex.DecodeString(masterKeyHex)
ts := strconv.FormatInt(time.Now().Unix(), 10)
canon := method + "\n" + path + "\n" + ts + "\n" + body
mac := hmac.New(sha256.New, key)
mac.Write([]byte(canon))
sig := hex.EncodeToString(mac.Sum(nil))
```

---

## 六、安全要求(认真读)

1. **rcsd 必须套 HTTPS。** 用 nginx + Let's Encrypt 反代,客户端配 `https://`。明文 HTTP 下虽然 secret 不上链路(只发 HMAC 签名),但请求体里的用户 email、key_id 都是明文,流量分析能拿到所有元数据。
2. **主密钥只放在网站后端服务器的环境变量里。** 不进代码仓库、不进前端、不发邮件、不写日志。
3. **网站后端调 rcsd 时,这台机器最好和 rcsd 同一个内网,或者通过受信任 IP 白名单访问。** 主密钥泄漏的后果是攻击者能签任意密钥、删任意密钥、改任意规则。
4. **签发出去的 secret 不要落网站任何持久存储。** 一次性展示完就让 GC 回收,内存里也别留太久。如果用户没复制走丢了,让他通过"密钥轮换"再生成新的,不要试图"找回原 secret"。
5. **审计日志:** rcsd 自动记录每次 `/api/keys` 调用到审计哈希链。你网站后端也建议自己记一份"何时为谁签发了什么档位的密钥",方便对账和事故复盘。
6. **rate limit:** 网站后端调 rcsd 不会被限流(主密钥不限速),但你网站对外的注册接口应该自己做限流,防止有人脚本注册刷免费档位。

---

## 七、用户体验小提示

- **密钥展示页**:大字号显示 `key_id` 和 `secret`,旁边各放一个"复制"按钮。下方加一句警告:"secret 仅显示一次,请立即妥善保存"。
- **邮件发送**:发不发看你产品定位。发的话**只发给已验证的注册邮箱**,且明确告知"邮箱被攻破等于密钥被攻破,建议关闭此邮件通知,密钥粘到密码管理器"。
- **客户端下载**:展示密钥的同一个页面,加客户端下载按钮(指向你存放安装包的 CDN 链接)。让用户下载 -> 安装 -> 填上面这把密钥,一步到位。
- **"忘记密钥"流程**:让用户在网站登录后,从订阅管理页面点"轮换密钥",调 `POST /api/keys/{id}/rotate`,新 secret 展示给他。
